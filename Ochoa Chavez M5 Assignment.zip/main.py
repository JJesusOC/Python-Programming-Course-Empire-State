# the main.py file
# where the total expenses and all will be calcualted


#this imports each module
from calculations import total_income, total_expense
import transactions


# values are added and will be calculated
def main():
    income = [500, 600, 550, 450]
    expense = [80, 200, 250, 600]
    income_total = total_income(income)
    expense_total = total_expense(expense)
    transactions.print_summary(income_total, expense_total)


# is necessary for the program to execute
if __name__ =="__main__":
    main()