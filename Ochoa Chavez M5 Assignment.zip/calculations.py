#budegting? done grades so lets give a go!!

# Here we will be doing the calculations necassary for the
# budgeting system.

# Gives all of the income values.
def total_income(income):
    return sum(income)

# Gives all of the expense values. 
def total_expense(expense):
    return sum(expense)