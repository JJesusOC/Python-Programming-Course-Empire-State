# our transactions page where all the expensise will be listed

from datetime import datetime

# This will give today's date with the following 
def today():
    return datetime.today().strftime("%m %d %Y")

def print_summary(income, expense):
    print(f"Date: {today()}")
    print(f"Total Income: ${income: .2f}")
    print(f"Total expense: $${expense: 2f}")
    print(f"Net:  ${income - expense: 2f}")


